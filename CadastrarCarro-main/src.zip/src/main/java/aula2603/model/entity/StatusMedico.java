package aula2603.model.entity;

public enum StatusMedico {
    ATIVO,
    INATIVO,
    FERIAS,
    LICENCA
}
package aula2603.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import aula2603.model.entity.Role;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {

    /**
     * Busca uma role pelo nome
     * @param nome o nome da role
     * @return a role encontrada ou null
     */
    Role findByNome(String nome);

    /**
     * Verifica se existe uma role com o nome informado
     * @param nome o nome a ser verificado
     * @return true se existir, false caso contrário
     */
    boolean existsByNome(String nome);
}

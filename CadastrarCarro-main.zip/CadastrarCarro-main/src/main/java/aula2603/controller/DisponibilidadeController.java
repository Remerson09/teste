package aula2603.controller;

import aula2603.model.entity.Agenda;
import aula2603.model.entity.AgendaStatus;
import aula2603.model.entity.Disponibilidade;
import aula2603.model.entity.StatusMedico;
import aula2603.repository.AgendaRepository;
import aula2603.repository.DisponibilidadeRepository;
import aula2603.repository.MedicoRepository;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/disponibilidade")
public class DisponibilidadeController {

    @Autowired
    private DisponibilidadeRepository disponibilidadeRepository;

    @Autowired
    private MedicoRepository medicoRepository;

    @Autowired
    private AgendaRepository agendaRepository;

    // -------------------------------
    // FORMULÁRIO NOVA DISPONIBILIDADE
    // -------------------------------
    @GetMapping("/nova")
    public String novaDisponibilidadeForm(Model model) {
        model.addAttribute("disponibilidade", new Disponibilidade());
        model.addAttribute("medicos", medicoRepository.findByStatus(StatusMedico.ATIVO));
        return "disponibilidade/form";
    }

    // -------------------------------
    // SALVAR DISPONIBILIDADE
    // -------------------------------
    @PostMapping("/salvar")
    public String salvarDisponibilidade(@Valid @ModelAttribute("disponibilidade") Disponibilidade disponibilidade,
                                        BindingResult result,
                                        RedirectAttributes redirectAttributes,
                                        Model model) {

        // Validações customizadas
        if (disponibilidade.getDataFinal().isBefore(disponibilidade.getDataInicial())) {
            result.rejectValue("dataFinal", "error.disponibilidade",
                    "A data final deve ser posterior ou igual à data inicial");
        }

        if (disponibilidade.getHorarioFim().isBefore(disponibilidade.getHorarioInicio()) ||
                disponibilidade.getHorarioFim().equals(disponibilidade.getHorarioInicio())) {
            result.rejectValue("horarioFim", "error.disponibilidade",
                    "O horário final deve ser posterior ao horário inicial");
        }

        // Validação do intervalo se informado
        if (disponibilidade.temIntervalo()) {
            if (disponibilidade.getIntervaloFim().isBefore(disponibilidade.getIntervaloInicio()) ||
                    disponibilidade.getIntervaloFim().equals(disponibilidade.getIntervaloInicio())) {
                result.rejectValue("intervaloFim", "error.disponibilidade",
                        "O horário final do intervalo deve ser posterior ao horário inicial");
            }

            if (disponibilidade.getIntervaloInicio().isBefore(disponibilidade.getHorarioInicio()) ||
                    disponibilidade.getIntervaloFim().isAfter(disponibilidade.getHorarioFim())) {
                result.rejectValue("intervaloInicio", "error.disponibilidade",
                        "O intervalo deve estar dentro do horário de funcionamento");
            }
        }

        // Verificar conflitos de horário
        if (disponibilidade.getId() == null) { // Nova disponibilidade
            boolean temConflito = disponibilidadeRepository.existeConflitoHorario(
                    disponibilidade.getMedico(),
                    0L, // ID 0 para nova disponibilidade
                    disponibilidade.getDataInicial(),
                    disponibilidade.getDataFinal(),
                    disponibilidade.getHorarioInicio(),
                    disponibilidade.getHorarioFim()
            );

            if (temConflito) {
                result.rejectValue("dataInicial", "error.disponibilidade",
                        "Conflito de horário com disponibilidades existentes");
            }
        }

        if (result.hasErrors()) {
            model.addAttribute("disponibilidade", disponibilidade);
            model.addAttribute("medicos", medicoRepository.findByStatus(StatusMedico.ATIVO));
            return "disponibilidade/form";
        }

        try {
            disponibilidadeRepository.save(disponibilidade);
            redirectAttributes.addFlashAttribute("success",
                    "Disponibilidade cadastrada com sucesso!");
            return "redirect:/disponibilidade/list";
        } catch (Exception e) {
            model.addAttribute("error", "Erro ao salvar disponibilidade: " + e.getMessage());
            model.addAttribute("disponibilidade", disponibilidade);
            model.addAttribute("medicos", medicoRepository.findByStatus(StatusMedico.ATIVO));
            return "disponibilidade/form";
        }
    }

    // -------------------------------
    // LISTAR DISPONIBILIDADES
    // -------------------------------
    @GetMapping("/list")
    public String listarDisponibilidades(Model model) {
        List<Disponibilidade> disponibilidades = disponibilidadeRepository.findAllWithMedico();
        model.addAttribute("disponibilidades", disponibilidades);
        return "disponibilidade/list";
    }

    // -------------------------------
    // PESQUISAR POR MÊS/ANO
    // -------------------------------
    @PostMapping("/pesquisar-mes-ano")
    public String pesquisarMesAno(@RequestParam("mesAno") String mesAno,
                                  Model model,
                                  RedirectAttributes redirectAttributes) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-yyyy");
            YearMonth yearMonth = YearMonth.parse(mesAno, formatter);
            int mes = yearMonth.getMonthValue();
            int ano = yearMonth.getYear();

            List<Disponibilidade> disponibilidades = disponibilidadeRepository.findByMes(mes, ano);

            model.addAttribute("disponibilidades", disponibilidades);
            model.addAttribute("mesAnoSelecionado", mesAno);

            if (disponibilidades.isEmpty()) {
                model.addAttribute("mensagem", "Nenhuma disponibilidade encontrada para " +
                        yearMonth.format(DateTimeFormatter.ofPattern("MM/yyyy")));
            }

            return "disponibilidade/list";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Erro ao pesquisar: " + e.getMessage());
            return "redirect:/disponibilidade/list";
        }
    }

    // -------------------------------
    // PESQUISAR POR PERÍODO
    // -------------------------------
    @GetMapping("/pesquisar")
    public String pesquisarPorPeriodo(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataInicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dataFim,
            @RequestParam(required = false) Long medicoId,
            Model model) {

        List<Disponibilidade> disponibilidades;

        try {
            if (dataInicio != null && dataFim != null) {
                if (medicoId != null) {
                    // Buscar por médico e período
                    var medico = medicoRepository.findById(medicoId)
                            .orElseThrow(() -> new IllegalArgumentException("Médico não encontrado"));
                    disponibilidades = disponibilidadeRepository.findByMedico(medico)
                            .stream()
                            .filter(d -> !d.getDataFinal().isBefore(dataInicio) &&
                                    !d.getDataInicial().isAfter(dataFim))
                            .toList();
                } else {
                    // Buscar apenas por período
                    disponibilidades = disponibilidadeRepository.findByPeriodo(dataInicio, dataFim);
                }
            } else if (medicoId != null) {
                // Buscar apenas por médico
                var medico = medicoRepository.findById(medicoId)
                        .orElseThrow(() -> new IllegalArgumentException("Médico não encontrado"));
                disponibilidades = disponibilidadeRepository.findByMedicoOrderByDataInicial(medico);
            } else {
                // Buscar todas
                disponibilidades = disponibilidadeRepository.findAllWithMedico();
            }

            model.addAttribute("disponibilidades", disponibilidades);
            model.addAttribute("dataInicio", dataInicio);
            model.addAttribute("dataFim", dataFim);
            model.addAttribute("medicoSelecionado", medicoId);
            model.addAttribute("medicos", medicoRepository.findByStatus(StatusMedico.ATIVO));

            return "disponibilidade/list";

        } catch (Exception e) {
            model.addAttribute("error", "Erro ao pesquisar: " + e.getMessage());
            model.addAttribute("disponibilidades", disponibilidadeRepository.findAllWithMedico());
            model.addAttribute("medicos", medicoRepository.findByStatus(StatusMedico.ATIVO));
            return "disponibilidade/list";
        }
    }

    // -------------------------------
    // EDITAR DISPONIBILIDADE
    // -------------------------------
    @GetMapping("/editar/{id}")
    public String editarDisponibilidade(@PathVariable Long id, Model model) {
        Disponibilidade disponibilidade = disponibilidadeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Disponibilidade não encontrada"));

        model.addAttribute("disponibilidade", disponibilidade);
        model.addAttribute("medicos", medicoRepository.findByStatus(StatusMedico.ATIVO));
        return "disponibilidade/form";
    }

    // -------------------------------
    // ATUALIZAR DISPONIBILIDADE
    // -------------------------------
    @PostMapping("/atualizar/{id}")
    public String atualizarDisponibilidade(@PathVariable Long id,
                                           @Valid @ModelAttribute("disponibilidade") Disponibilidade disponibilidade,
                                           BindingResult result,
                                           RedirectAttributes redirectAttributes,
                                           Model model) {

        // Validações (mesmo código do salvar)
        if (disponibilidade.getDataFinal().isBefore(disponibilidade.getDataInicial())) {
            result.rejectValue("dataFinal", "error.disponibilidade",
                    "A data final deve ser posterior ou igual à data inicial");
        }

        if (disponibilidade.getHorarioFim().isBefore(disponibilidade.getHorarioInicio()) ||
                disponibilidade.getHorarioFim().equals(disponibilidade.getHorarioInicio())) {
            result.rejectValue("horarioFim", "error.disponibilidade",
                    "O horário final deve ser posterior ao horário inicial");
        }

        if (result.hasErrors()) {
            disponibilidade.setId(id);
            model.addAttribute("disponibilidade", disponibilidade);
            model.addAttribute("medicos", medicoRepository.findByStatus(StatusMedico.ATIVO));
            return "disponibilidade/form";
        }

        try {
            disponibilidade.setId(id);
            disponibilidadeRepository.save(disponibilidade);
            redirectAttributes.addFlashAttribute("success",
                    "Disponibilidade atualizada com sucesso!");
            return "redirect:/disponibilidade/list";
        } catch (Exception e) {
            model.addAttribute("error", "Erro ao atualizar: " + e.getMessage());
            model.addAttribute("disponibilidade", disponibilidade);
            model.addAttribute("medicos", medicoRepository.findByStatus(StatusMedico.ATIVO));
            return "disponibilidade/form";
        }
    }

    // -------------------------------
    // EXCLUIR DISPONIBILIDADE
    // -------------------------------
    @GetMapping("/excluir/{id}")
    public String excluirDisponibilidade(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            Disponibilidade disponibilidade = disponibilidadeRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Disponibilidade não encontrada"));

            // Verificar se existem agendas associadas
            List<Agenda> agendasAssociadas = agendaRepository.findByMedicoAndDataHoraInicioBetween(
                    disponibilidade.getMedico(),
                    disponibilidade.getDataInicial().atTime(disponibilidade.getHorarioInicio()),
                    disponibilidade.getDataFinal().atTime(disponibilidade.getHorarioFim())
            );

            if (!agendasAssociadas.isEmpty()) {
                redirectAttributes.addFlashAttribute("error",
                        "Não é possível excluir esta disponibilidade pois existem agendas associadas.");
                return "redirect:/disponibilidade/list";
            }

            disponibilidadeRepository.deleteById(id);
            redirectAttributes.addFlashAttribute("success",
                    "Disponibilidade excluída com sucesso!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error",
                    "Erro ao excluir disponibilidade: " + e.getMessage());
        }
        return "redirect:/disponibilidade/list";
    }

    // -------------------------------
    // GERAR AGENDAS A PARTIR DA DISPONIBILIDADE
    // -------------------------------
    @PostMapping("/gerar-agendas/{id}")
    public String gerarAgendasDeDisponibilidade(@PathVariable Long id,
                                                RedirectAttributes redirectAttributes) {
        try {
            Disponibilidade disponibilidade = disponibilidadeRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Disponibilidade não encontrada"));

            List<Agenda> agendasGeradas = gerarAgendasAutomaticamente(disponibilidade);

            if (agendasGeradas.isEmpty()) {
                redirectAttributes.addFlashAttribute("warning",
                        "Nenhuma agenda foi gerada. Verifique os parâmetros da disponibilidade.");
                return "redirect:/disponibilidade/list";
            }

            agendaRepository.saveAll(agendasGeradas);

            redirectAttributes.addFlashAttribute("success",
                    String.format("Geradas %d agendas com sucesso!", agendasGeradas.size()));

            return "redirect:/agendas/disponiveis";

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error",
                    "Erro ao gerar agendas: " + e.getMessage());
            return "redirect:/disponibilidade/list";
        }
    }

    // -------------------------------
    // MÉTODO AUXILIAR PARA GERAR AGENDAS
    // -------------------------------
    private List<Agenda> gerarAgendasAutomaticamente(Disponibilidade disponibilidade) {
        List<Agenda> agendas = new ArrayList<>();

        LocalDate dataAtual = disponibilidade.getDataInicial();

        // Converter tempo de consulta para minutos
        int minutosConsulta = disponibilidade.getTempoConsulta().getHour() * 60 +
                disponibilidade.getTempoConsulta().getMinute();

        while (!dataAtual.isAfter(disponibilidade.getDataFinal())) {
            LocalTime horarioAtual = disponibilidade.getHorarioInicio();

            while (horarioAtual.isBefore(disponibilidade.getHorarioFim())) {
                // Verifica se não está no intervalo
                if (disponibilidade.temIntervalo() &&
                        !horarioAtual.isBefore(disponibilidade.getIntervaloInicio()) &&
                        horarioAtual.isBefore(disponibilidade.getIntervaloFim())) {
                    horarioAtual = disponibilidade.getIntervaloFim();
                    continue;
                }

                LocalDateTime dataHoraInicio = dataAtual.atTime(horarioAtual);
                LocalDateTime dataHoraFim = dataHoraInicio.plusMinutes(minutosConsulta);

                // Verifica se não ultrapassa o horário de fim
                if (dataHoraFim.toLocalTime().isAfter(disponibilidade.getHorarioFim())) {
                    break;
                }

                // Verifica se já existe agenda neste horário
                List<Agenda> conflitos = agendaRepository.findConflitosDeHorario(
                        disponibilidade.getMedico(),
                        dataHoraInicio,
                        dataHoraFim
                );

                if (conflitos.isEmpty()) {
                    Agenda agenda = new Agenda(dataHoraInicio, dataHoraFim, disponibilidade.getMedico());
                    agenda.setStatus(AgendaStatus.DISPONIVEL);
                    agendas.add(agenda);
                }

                horarioAtual = dataHoraFim.toLocalTime();
            }

            dataAtual = dataAtual.plusDays(1);
        }

        return agendas;
    }

    // -------------------------------
    // VISUALIZAR DETALHES
    // -------------------------------
    @GetMapping("/detalhes/{id}")
    public String visualizarDetalhes(@PathVariable Long id, Model model) {
        Disponibilidade disponibilidade = disponibilidadeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Disponibilidade não encontrada"));

        // Buscar agendas relacionadas
        List<Agenda> agendasRelacionadas = agendaRepository.findByMedicoAndDataHoraInicioBetween(
                disponibilidade.getMedico(),
                disponibilidade.getDataInicial().atTime(disponibilidade.getHorarioInicio()),
                disponibilidade.getDataFinal().atTime(disponibilidade.getHorarioFim())
        );

        model.addAttribute("disponibilidade", disponibilidade);
        model.addAttribute("agendasRelacionadas", agendasRelacionadas);
        return "disponibilidade/detalhes";
    }
}
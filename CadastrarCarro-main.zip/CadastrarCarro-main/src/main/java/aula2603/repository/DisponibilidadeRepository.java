package aula2603.repository;

import aula2603.model.entity.Disponibilidade;
import aula2603.model.entity.Medico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface DisponibilidadeRepository extends JpaRepository<Disponibilidade, Long> {

    /**
     * Busca todas as disponibilidades de um médico
     */
    List<Disponibilidade> findByMedico(Medico medico);

    /**
     * Busca disponibilidades de um médico ordenadas por data inicial
     */
    List<Disponibilidade> findByMedicoOrderByDataInicial(Medico medico);

    /**
     * Busca disponibilidades de um médico em uma data específica
     */
    @Query("SELECT d FROM Disponibilidade d WHERE " +
            "d.medico = :medico AND " +
            "d.dataInicial <= :data AND " +
            "d.dataFinal >= :data")
    List<Disponibilidade> findByMedicoAndData(
            @Param("medico") Medico medico,
            @Param("data") LocalDate data);

    /**
     * Busca disponibilidades por mês e ano
     */
    @Query("SELECT d FROM Disponibilidade d WHERE " +
            "MONTH(d.dataInicial) = :mes AND " +
            "YEAR(d.dataInicial) = :ano " +
            "ORDER BY d.dataInicial, d.horarioInicio")
    List<Disponibilidade> findByMes(
            @Param("mes") int mes,
            @Param("ano") int ano);

    /**
     * Busca disponibilidades em um período específico
     */
    @Query("SELECT d FROM Disponibilidade d WHERE " +
            "d.dataInicial BETWEEN :dataInicio AND :dataFim OR " +
            "d.dataFinal BETWEEN :dataInicio AND :dataFim OR " +
            "(d.dataInicial <= :dataInicio AND d.dataFinal >= :dataFim) " +
            "ORDER BY d.dataInicial, d.horarioInicio")
    List<Disponibilidade> findByPeriodo(
            @Param("dataInicio") LocalDate dataInicio,
            @Param("dataFim") LocalDate dataFim);

    /**
     * Busca disponibilidades futuras (a partir de hoje)
     */
    @Query("SELECT d FROM Disponibilidade d WHERE " +
            "d.dataFinal >= :dataAtual " +
            "ORDER BY d.dataInicial, d.horarioInicio")
    List<Disponibilidade> findDisponibilidadesFuturas(@Param("dataAtual") LocalDate dataAtual);

    /**
     * Busca disponibilidades futuras de um médico específico
     */
    @Query("SELECT d FROM Disponibilidade d WHERE " +
            "d.medico = :medico AND " +
            "d.dataFinal >= :dataAtual " +
            "ORDER BY d.dataInicial, d.horarioInicio")
    List<Disponibilidade> findDisponibilidadesFuturasByMedico(
            @Param("medico") Medico medico,
            @Param("dataAtual") LocalDate dataAtual);

    /**
     * Verifica se existe conflito de horário para um médico
     */
    @Query("SELECT CASE WHEN COUNT(d) > 0 THEN true ELSE false END " +
            "FROM Disponibilidade d WHERE " +
            "d.medico = :medico AND " +
            "d.id <> :id AND " +
            "((d.dataInicial BETWEEN :dataInicio AND :dataFim) OR " +
            "(d.dataFinal BETWEEN :dataInicio AND :dataFim) OR " +
            "(d.dataInicial <= :dataInicio AND d.dataFinal >= :dataFim)) AND " +
            "((d.horarioInicio < :horarioFim AND d.horarioFim > :horarioInicio))")
    boolean existeConflitoHorario(
            @Param("medico") Medico medico,
            @Param("id") Long id,
            @Param("dataInicio") LocalDate dataInicio,
            @Param("dataFim") LocalDate dataFim,
            @Param("horarioInicio") java.time.LocalTime horarioInicio,
            @Param("horarioFim") java.time.LocalTime horarioFim);

    /**
     * Busca disponibilidades com JOIN FETCH para evitar N+1
     */
    @Query("SELECT d FROM Disponibilidade d JOIN FETCH d.medico " +
            "ORDER BY d.dataInicial, d.horarioInicio")
    List<Disponibilidade> findAllWithMedico();

    /**
     * Busca disponibilidades de médicos ativos
     */
    @Query("SELECT d FROM Disponibilidade d JOIN FETCH d.medico m " +
            "WHERE m.status = 'ATIVO' " +
            "ORDER BY d.dataInicial, d.horarioInicio")
    List<Disponibilidade> findByMedicoAtivo();

    /**
     * Busca disponibilidades por especialidade
     */
    @Query("SELECT d FROM Disponibilidade d JOIN FETCH d.medico m " +
            "WHERE m.especialidade = :especialidade AND " +
            "d.dataFinal >= :dataAtual " +
            "ORDER BY d.dataInicial, d.horarioInicio")
    List<Disponibilidade> findByEspecialidade(
            @Param("especialidade") String especialidade,
            @Param("dataAtual") LocalDate dataAtual);

    /**
     * Conta disponibilidades de um médico
     */
    long countByMedico(Medico medico);

    /**
     * Busca disponibilidades que incluem uma data específica
     */
    @Query("SELECT d FROM Disponibilidade d WHERE " +
            "d.dataInicial <= :data AND " +
            "d.dataFinal >= :data " +
            "ORDER BY d.horarioInicio")
    List<Disponibilidade> findByDataIncluida(@Param("data") LocalDate data);

    /**
     * Remove disponibilidades antigas (anteriores a uma data)
     */
    void deleteByDataFinalBefore(LocalDate data);
}
package aula2603.model.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "disponibilidade")
public class Disponibilidade {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "O médico deve ser selecionado")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "medico_id", nullable = false)
    private Medico medico;

    @NotNull(message = "A data inicial é obrigatória")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Column(name = "data_inicial")
    private LocalDate dataInicial;

    @NotNull(message = "A data final é obrigatória")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Column(name = "data_final")
    private LocalDate dataFinal;

    @NotNull(message = "O horário de início é obrigatório")
    @DateTimeFormat(pattern = "HH:mm")
    @Column(name = "horario_inicio")
    private LocalTime horarioInicio;

    @NotNull(message = "O horário de fim é obrigatório")
    @DateTimeFormat(pattern = "HH:mm")
    @Column(name = "horario_fim")
    private LocalTime horarioFim;

    @DateTimeFormat(pattern = "HH:mm")
    @Column(name = "intervalo_inicio")
    private LocalTime intervaloInicio;

    @DateTimeFormat(pattern = "HH:mm")
    @Column(name = "intervalo_fim")
    private LocalTime intervaloFim;

    @NotNull(message = "O tempo de consulta é obrigatório")
    @DateTimeFormat(pattern = "HH:mm")
    @Column(name = "tempo_consulta")
    private LocalTime tempoConsulta;

    // Construtores
    public Disponibilidade() {}

    public Disponibilidade(Medico medico, LocalDate dataInicial, LocalDate dataFinal,
                           LocalTime horarioInicio, LocalTime horarioFim, LocalTime tempoConsulta) {
        this.medico = medico;
        this.dataInicial = dataInicial;
        this.dataFinal = dataFinal;
        this.horarioInicio = horarioInicio;
        this.horarioFim = horarioFim;
        this.tempoConsulta = tempoConsulta;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public LocalDate getDataInicial() {
        return dataInicial;
    }

    public void setDataInicial(LocalDate dataInicial) {
        this.dataInicial = dataInicial;
    }

    public LocalDate getDataFinal() {
        return dataFinal;
    }

    public void setDataFinal(LocalDate dataFinal) {
        this.dataFinal = dataFinal;
    }

    public LocalTime getHorarioInicio() {
        return horarioInicio;
    }

    public void setHorarioInicio(LocalTime horarioInicio) {
        this.horarioInicio = horarioInicio;
    }

    public LocalTime getHorarioFim() {
        return horarioFim;
    }

    public void setHorarioFim(LocalTime horarioFim) {
        this.horarioFim = horarioFim;
    }

    public LocalTime getIntervaloInicio() {
        return intervaloInicio;
    }

    public void setIntervaloInicio(LocalTime intervaloInicio) {
        this.intervaloInicio = intervaloInicio;
    }

    public LocalTime getIntervaloFim() {
        return intervaloFim;
    }

    public void setIntervaloFim(LocalTime intervaloFim) {
        this.intervaloFim = intervaloFim;
    }

    public LocalTime getTempoConsulta() {
        return tempoConsulta;
    }

    public void setTempoConsulta(LocalTime tempoConsulta) {
        this.tempoConsulta = tempoConsulta;
    }

    // Métodos auxiliares
    public boolean isValidoPeriodo() {
        return dataFinal.isAfter(dataInicial) || dataFinal.isEqual(dataInicial);
    }

    public boolean isValidoHorario() {
        return horarioFim.isAfter(horarioInicio);
    }

    public boolean temIntervalo() {
        return intervaloInicio != null && intervaloFim != null;
    }

    public boolean isValidoIntervalo() {
        if (!temIntervalo()) {
            return true; // Se não tem intervalo, é válido
        }
        return intervaloFim.isAfter(intervaloInicio) &&
                intervaloInicio.isAfter(horarioInicio) &&
                intervaloFim.isBefore(horarioFim);
    }

    public String getPeriodoFormatado() {
        return dataInicial.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")) +
                " a " +
                dataFinal.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }

    public String getHorarioFormatado() {
        return horarioInicio.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm")) +
                " às " +
                horarioFim.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
    }

    public String dados() {
        return "Disponibilidade: " + getPeriodoFormatado() +
                " | Horário: " + getHorarioFormatado() +
                " | Médico: " + (medico != null ? medico.getNome() : "N/A") +
                " | Tempo consulta: " + tempoConsulta.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
    }

    @PrePersist
    @PreUpdate
    private void validarDados() {
        if (!isValidoPeriodo()) {
            throw new IllegalArgumentException("A data final deve ser posterior ou igual à data inicial");
        }
        if (!isValidoHorario()) {
            throw new IllegalArgumentException("O horário final deve ser posterior ao horário inicial");
        }
        if (!isValidoIntervalo()) {
            throw new IllegalArgumentException("O intervalo deve estar dentro do horário de funcionamento");
        }
    }

    @Override
    public String toString() {
        return "Disponibilidade{" +
                "id=" + id +
                ", medico=" + (medico != null ? medico.getNome() : "null") +
                ", dataInicial=" + dataInicial +
                ", dataFinal=" + dataFinal +
                ", horarioInicio=" + horarioInicio +
                ", horarioFim=" + horarioFim +
                ", tempoConsulta=" + tempoConsulta +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Disponibilidade that = (Disponibilidade) o;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
